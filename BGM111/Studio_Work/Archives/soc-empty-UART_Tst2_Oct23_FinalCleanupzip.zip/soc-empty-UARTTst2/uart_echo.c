/*
 * uart_echo.c
 *
 *  Created on: 2016.04.20.
 *      Author: baadamff
 */

/* Board support header */
#include "bsp.h"

/* emlib & emdrv */
#include "em_int.h"
#include "em_emu.h"
#include "em_gpio.h"

#include "uartdrv.h"
#include "uart_echo.h"
#include <stdio.h>
#include <string.h>



#define NUM_TX_BUFFERS          8

/***************************************************************************************************
 Local Variables
 **************************************************************************************************/

/***************************************************************************************************
 Public Function Definitions
 **************************************************************************************************/
void UART_Test(void)
{
	char test_string[20];
	strcpy(test_string, "SPP server\r\n");
	int i, size;

	/* Enable VCOM */
	//GPIO_PinModeSet(BSP_BCC_ENABLE_PORT, BSP_BCC_ENABLE_PIN, gpioModePushPull, 1);
	//GPIO_PinOutSet(BSP_BCC_ENABLE_PORT, BSP_BCC_ENABLE_PIN);

	/* uart init */
	//UARTDRV_Init_t initData;

	//DEFINE_BUF_QUEUE(EMDRV_UARTDRV_MAX_CONCURRENT_RX_BUFS, rxBufferQueueI0);
	//DEFINE_BUF_QUEUE(EMDRV_UARTDRV_MAX_CONCURRENT_TX_BUFS, txBufferQueueI0);


	/* UART init */
	//initData.port                 = USART1;
	//initData.baudRate             = 115200;
	//initData.portLocationTx       = USART_ROUTELOC0_TXLOC_LOC14;
	//initData.portLocationRx       = USART_ROUTELOC0_RXLOC_LOC12;
	//initData.stopBits             = (USART_Stopbits_TypeDef) USART_FRAME_STOPBITS_ONE;
	//initData.parity               = (USART_Parity_TypeDef) USART_FRAME_PARITY_NONE;
	//initData.oversampling         = (USART_OVS_TypeDef) USART_CTRL_OVS_X16;
	//initData.mvdis                = false;
	//initData.fcType               = uartdrvFlowControlNone;
	//initData.rxQueue              = (UARTDRV_Buffer_FifoQueue_t *)&rxBufferQueueI0;
	//initData.txQueue              = (UARTDRV_Buffer_FifoQueue_t *)&txBufferQueueI0;

	//UARTDRV_Init(testHandle0, &initData);
	//UARTDRV_Transmit(testHandle0, (uint8_t *)"OK?\r\n", 5, UART_tx_callback);
	//UARTDRV_Receive(testHandle0, &rxByte, 1, UART_rx_callback);

	// More Test Code
	while(1)
	{
		size = 12;
		//size = sizeof(test_string);
    	for(i=0; i<size; i++)
	    //for(i=0; i<sizeof(test_string); i++)
	        USART_Tx (USART1, test_string[i]);
	}

}


